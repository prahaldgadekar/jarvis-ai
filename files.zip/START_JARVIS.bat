@echo off
title JARVIS Launcher
color 0B

echo.
echo  ============================================
echo    J.A.R.V.I.S  --  Starting Up...
echo  ============================================
echo.

:: ── Step 1: Check if Ollama is already running ──────────────
echo  [1/3] Checking Ollama...
curl -s http://localhost:11434/api/tags >nul 2>&1
if %errorlevel% == 0 (
    echo        Ollama already running. OK.
) else (
    echo        Starting Ollama...
    start "" /B "C:\Users\%USERNAME%\AppData\Local\Programs\Ollama\ollama.exe" serve
    :: Wait up to 15 seconds for Ollama to come online
    set /a tries=0
    :WAIT_LOOP
    timeout /t 1 /nobreak >nul
    curl -s http://localhost:11434/api/tags >nul 2>&1
    if %errorlevel% == 0 goto OLLAMA_READY
    set /a tries+=1
    if %tries% LSS 15 goto WAIT_LOOP
    echo  [!] Ollama failed to start. Check installation.
    pause
    exit /b 1
    :OLLAMA_READY
    echo        Ollama started. OK.
)

:: ── Step 2: Check models are available ──────────────────────
echo  [2/3] Checking AI models...
curl -s http://localhost:11434/api/tags | findstr /i "llama" >nul 2>&1
if %errorlevel% == 0 (
    echo        Models found. OK.
) else (
    echo  [!] No models found. Pulling llama3.1 now...
    ollama pull llama3.1
)

:: ── Step 3: Launch JARVIS ────────────────────────────────────
echo  [3/3] Launching JARVIS...
echo.
echo  ============================================
echo    JARVIS is starting. Enjoy!
echo  ============================================
echo.

cd /d E:\jarvis
start "" pythonw jarvis.py

:: Close this launcher window after 2 seconds
timeout /t 2 /nobreak >nul
exit
